#!/usr/bin/env bash

rm "$1"