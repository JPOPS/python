#!/usr/bin/env bash

echo "win" > "$1"