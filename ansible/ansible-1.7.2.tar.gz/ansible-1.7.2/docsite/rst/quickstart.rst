Quickstart Video
````````````````

We've recorded a short video that shows how to get started with Ansible that you may like to use alongside the documentation.

The `quickstart video <http://ansible.com/ansible-resources>`_ is about 20 minutes long and will show you some of the basics about your
first steps with Ansible.

Enjoy, and be sure to visit the rest of the documentation to learn more.
