Ansible Guru 
````````````

While many users should be able to get on fine with the documentation, mailing list, and IRC, sometimes you want a bit more.

`Ansible Guru <http://ansible.com/ansible-guru>`_ is an offering from Ansible, Inc that helps users who would like more dedicated help with Ansible, including building playbooks, best practices, architecture suggestions, and more -- all from our awesome support and services team.  It also includes some useful discounts and also some free T-shirts, though you shouldn't get it just for the free shirts!  It's a great way to train up to becoming an Ansible expert.

For those interested, click through the link above.  You can sign up in minutes!

For users looking for more hands-on help, we also have some more information on our `Services page <http://www.ansible.com/ansible-services>`_, and support is also included with :doc:`tower`.
