Gentoo ebuilds are available here:

https://github.com/uu/ubuilds
